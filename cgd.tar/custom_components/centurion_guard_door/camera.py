from __future__ import annotations

from homeassistant.components.mjpeg.camera import MjpegCamera
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import CONF_HOST, DOMAIN


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    host = entry.data[CONF_HOST]
    async_add_entities([CenturionCamera(host)])


class CenturionCamera(MjpegCamera):
    _attr_has_entity_name = True
    _attr_name = "Camera"

    def __init__(self, host: str) -> None:
        super().__init__(mjpeg_url=f"http://{host}:88/")
        self._attr_unique_id = f"{host}_camera"
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, host)},
            name="Centurion Guard Door",
            manufacturer="Centurion",
            model="Guard Door",
        )
